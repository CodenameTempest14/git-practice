char = input("Input a character: ")

if char.islower():
    print(f"Output: {char.upper()}")
else:
    print(f"Output: {char.lower()}")